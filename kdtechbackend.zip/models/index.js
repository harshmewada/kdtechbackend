module.exports.User = require("./user.model");
module.exports.Category = require("./category.model");
module.exports.Platform = require("./platform.model");
module.exports.Product = require("./product.model");
module.exports.Offer = require("./offer.model");
