module.exports.businessValidation = require('./business.validation')
module.exports.festivalValidation = require('./festival.validation')
module.exports.subcategoryValidation = require('./subcategory.validation')
module.exports.postValidation = require('./post.validation')