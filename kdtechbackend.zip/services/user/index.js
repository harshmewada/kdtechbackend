module.exports.authService = require("./auth.service");
module.exports.categoryService = require("./category.service");
module.exports.exploreService = require("./explore.service");
module.exports.productService = require("./product.service");
module.exports.offerService = require("./offer.service");
