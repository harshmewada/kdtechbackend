module.exports.authController = require("./auth.controller");
module.exports.userController = require("./user.controller");
module.exports.platformController = require("./platform.controller");
module.exports.categoryController = require("./category.controller");
module.exports.productController = require("./product.controller");
module.exports.offerController = require("./offer.controller");
