module.exports.dashboardService = require("./dashboard.service");
module.exports.authService = require("./auth.service");
module.exports.userService = require("./user.service");
module.exports.platformService = require("./platform.service");
module.exports.categoryService = require("./category.service");
module.exports.productService = require("./product.service");
module.exports.offerService = require("./offer.service");