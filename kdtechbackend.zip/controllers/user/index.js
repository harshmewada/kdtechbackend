module.exports.auth = require("./auth.controller");
module.exports.exploreController = require("./explore.controller");
module.exports.categoryController = require("./category.controller");
module.exports.productController = require("./product.controller");
module.exports.offerController = require("./offer.controller");
